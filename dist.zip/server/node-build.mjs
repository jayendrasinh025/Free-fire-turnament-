import path from "path";
import "dotenv/config";
import * as express from "express";
import express__default from "express";
import cors from "cors";
import mysql from "mysql2/promise";
const handleDemo = (req, res) => {
  const response = {
    message: "Hello from Express server"
  };
  res.status(200).json(response);
};
const pool = mysql.createPool({
  host: process.env.MYSQL_HOST || "localhost",
  user: process.env.MYSQL_USER || "root",
  password: process.env.MYSQL_PASSWORD || "",
  database: process.env.MYSQL_DATABASE || "fire_tournament",
  port: parseInt(process.env.MYSQL_PORT || "3306"),
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});
async function initializeDatabase() {
  try {
    const connection = await pool.getConnection();
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS registrations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        player_name VARCHAR(255) NOT NULL,
        player_uid VARCHAR(255) NOT NULL,
        player_mobile VARCHAR(20) NOT NULL,
        mode ENUM('squad', 'solo') NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS payments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        registration_id INT NOT NULL,
        utr VARCHAR(255) NOT NULL,
        transaction_id VARCHAR(255) NOT NULL,
        mobile VARCHAR(20) NOT NULL,
        amount DECIMAL(10, 2) DEFAULT 0,
        status ENUM('pending', 'confirmed', 'failed') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (registration_id) REFERENCES registrations(id) ON DELETE CASCADE
      )
    `);
    connection.release();
    console.log("Database initialized successfully");
  } catch (error) {
    console.error("Database initialization error:", error);
    throw error;
  }
}
const handleRegister = async (req, res) => {
  try {
    const { playerName, playerUid, playerMobile, mode } = req.body;
    if (!playerName || !playerUid || !playerMobile || !mode) {
      res.status(400).json({
        success: false,
        message: "Missing required fields",
        error: "playerName, playerUid, playerMobile, and mode are required"
      });
      return;
    }
    if (!["squad", "solo"].includes(mode)) {
      res.status(400).json({
        success: false,
        message: "Invalid mode",
        error: 'mode must be either "squad" or "solo"'
      });
      return;
    }
    const connection = await pool.getConnection();
    const [result] = await connection.execute(
      "INSERT INTO registrations (player_name, player_uid, player_mobile, mode) VALUES (?, ?, ?, ?)",
      [playerName, playerUid, playerMobile, mode]
    );
    connection.release();
    res.status(201).json({
      success: true,
      message: "Registration successful",
      registrationId: result.insertId
    });
  } catch (error) {
    console.error("Registration error:", error);
    res.status(500).json({
      success: false,
      message: "Registration failed",
      error: error instanceof Error ? error.message : "Unknown error"
    });
  }
};
const handlePayment = async (req, res) => {
  try {
    const { registrationId, utr, transactionId, mobile, amount } = req.body;
    if (!registrationId || !utr || !transactionId || !mobile) {
      res.status(400).json({
        success: false,
        message: "Missing required fields",
        error: "registrationId, utr, transactionId, and mobile are required"
      });
      return;
    }
    const connection = await pool.getConnection();
    const [registrationCheck] = await connection.execute(
      "SELECT id FROM registrations WHERE id = ?",
      [registrationId]
    );
    if (registrationCheck.length === 0) {
      connection.release();
      res.status(404).json({
        success: false,
        message: "Registration not found",
        error: "Invalid registrationId"
      });
      return;
    }
    const [result] = await connection.execute(
      "INSERT INTO payments (registration_id, utr, transaction_id, mobile, amount, status) VALUES (?, ?, ?, ?, ?, ?)",
      [registrationId, utr, transactionId, mobile, amount || 0, "pending"]
    );
    connection.release();
    res.status(201).json({
      success: true,
      message: "Payment submitted successfully",
      paymentId: result.insertId
    });
  } catch (error) {
    console.error("Payment error:", error);
    res.status(500).json({
      success: false,
      message: "Payment submission failed",
      error: error instanceof Error ? error.message : "Unknown error"
    });
  }
};
const handleGetRegistrations = async (req, res) => {
  try {
    const connection = await pool.getConnection();
    const [registrations] = await connection.execute(`
      SELECT 
        r.id,
        r.player_name,
        r.player_uid,
        r.player_mobile,
        r.mode,
        r.created_at,
        p.id as payment_id,
        p.utr,
        p.transaction_id,
        p.mobile as payment_mobile,
        p.amount,
        p.status as payment_status,
        p.created_at as payment_created_at
      FROM registrations r
      LEFT JOIN payments p ON r.id = p.registration_id
      ORDER BY r.created_at DESC
    `);
    connection.release();
    res.json({
      success: true,
      message: "Registrations retrieved successfully",
      data: registrations
    });
  } catch (error) {
    console.error("Get registrations error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to retrieve registrations",
      error: error instanceof Error ? error.message : "Unknown error"
    });
  }
};
const handleDeleteRegistration = async (req, res) => {
  try {
    const { id } = req.params;
    if (!id || isNaN(parseInt(id))) {
      res.status(400).json({
        success: false,
        message: "Invalid registration ID",
        error: "Registration ID must be a valid number"
      });
      return;
    }
    const connection = await pool.getConnection();
    const [result] = await connection.execute(
      "DELETE FROM registrations WHERE id = ?",
      [parseInt(id)]
    );
    connection.release();
    if (result.affectedRows === 0) {
      res.status(404).json({
        success: false,
        message: "Registration not found",
        error: "No registration found with the given ID"
      });
      return;
    }
    res.json({
      success: true,
      message: "Registration deleted successfully"
    });
  } catch (error) {
    console.error("Delete registration error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to delete registration",
      error: error instanceof Error ? error.message : "Unknown error"
    });
  }
};
const handleDeleteAllRegistrations = async (req, res) => {
  try {
    const connection = await pool.getConnection();
    const [result] = await connection.execute("DELETE FROM registrations");
    connection.release();
    res.json({
      success: true,
      message: "All registrations deleted successfully",
      data: { deletedCount: result.affectedRows }
    });
  } catch (error) {
    console.error("Delete all registrations error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to delete registrations",
      error: error instanceof Error ? error.message : "Unknown error"
    });
  }
};
const handleGetPaymentSummary = async (req, res) => {
  try {
    const connection = await pool.getConnection();
    const [summary] = await connection.execute(`
      SELECT 
        COUNT(DISTINCT r.id) as total_registrations,
        COUNT(DISTINCT p.id) as total_payments,
        SUM(CASE WHEN p.status = 'confirmed' THEN p.amount ELSE 0 END) as total_confirmed_amount,
        COUNT(DISTINCT CASE WHEN p.status = 'pending' THEN p.id END) as pending_payments,
        COUNT(DISTINCT CASE WHEN p.status = 'confirmed' THEN p.id END) as confirmed_payments
      FROM registrations r
      LEFT JOIN payments p ON r.id = p.registration_id
    `);
    connection.release();
    res.json({
      success: true,
      message: "Payment summary retrieved successfully",
      data: summary[0]
    });
  } catch (error) {
    console.error("Get payment summary error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to retrieve payment summary",
      error: error instanceof Error ? error.message : "Unknown error"
    });
  }
};
async function createServer() {
  const app = express__default();
  try {
    await initializeDatabase();
  } catch (error) {
    console.error("Failed to initialize database:", error);
  }
  app.use(cors());
  app.use(express__default.json());
  app.use(express__default.urlencoded({ extended: true }));
  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });
  app.get("/api/demo", handleDemo);
  app.post("/api/register", handleRegister);
  app.post("/api/payment", handlePayment);
  app.get("/api/admin/registrations", handleGetRegistrations);
  app.delete("/api/admin/registrations/:id", handleDeleteRegistration);
  app.delete("/api/admin/registrations", handleDeleteAllRegistrations);
  app.get("/api/admin/payment-summary", handleGetPaymentSummary);
  return app;
}
async function startServer() {
  const app = await createServer();
  const port = process.env.PORT || 3e3;
  const __dirname = import.meta.dirname;
  const distPath = path.join(__dirname, "../spa");
  app.use(express.static(distPath));
  app.get("*", (req, res) => {
    if (req.path.startsWith("/api/") || req.path.startsWith("/health")) {
      return res.status(404).json({ error: "API endpoint not found" });
    }
    res.sendFile(path.join(distPath, "index.html"));
  });
  app.listen(port, () => {
    console.log(`🚀 Fusion Starter server running on port ${port}`);
    console.log(`📱 Frontend: http://localhost:${port}`);
    console.log(`🔧 API: http://localhost:${port}/api`);
  });
  process.on("SIGTERM", () => {
    console.log("🛑 Received SIGTERM, shutting down gracefully");
    process.exit(0);
  });
  process.on("SIGINT", () => {
    console.log("🛑 Received SIGINT, shutting down gracefully");
    process.exit(0);
  });
}
startServer().catch((error) => {
  console.error("Failed to start server:", error);
  process.exit(1);
});
//# sourceMappingURL=node-build.mjs.map
