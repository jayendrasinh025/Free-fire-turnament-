import { RequestHandler } from 'express';
import pool from '../db';

export interface RegisterRequest {
  playerName: string;
  playerUid: string;
  playerMobile: string;
  mode: 'squad' | 'solo';
}

export interface RegisterResponse {
  success: boolean;
  message: string;
  registrationId?: number;
  error?: string;
}

export const handleRegister: RequestHandler = async (req, res) => {
  try {
    const { playerName, playerUid, playerMobile, mode } = req.body as RegisterRequest;

    // Validation
    if (!playerName || !playerUid || !playerMobile || !mode) {
      res.status(400).json({
        success: false,
        message: 'Missing required fields',
        error: 'playerName, playerUid, playerMobile, and mode are required'
      } as RegisterResponse);
      return;
    }

    if (!['squad', 'solo'].includes(mode)) {
      res.status(400).json({
        success: false,
        message: 'Invalid mode',
        error: 'mode must be either "squad" or "solo"'
      } as RegisterResponse);
      return;
    }

    const connection = await pool.getConnection();
    
    const [result] = await connection.execute(
      'INSERT INTO registrations (player_name, player_uid, player_mobile, mode) VALUES (?, ?, ?, ?)',
      [playerName, playerUid, playerMobile, mode]
    );

    connection.release();

    res.status(201).json({
      success: true,
      message: 'Registration successful',
      registrationId: (result as any).insertId
    } as RegisterResponse);
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({
      success: false,
      message: 'Registration failed',
      error: error instanceof Error ? error.message : 'Unknown error'
    } as RegisterResponse);
  }
};
