import { RequestHandler } from 'express';
import pool from '../db';

export interface PaymentRequest {
  registrationId: number;
  utr: string;
  transactionId: string;
  mobile: string;
  amount?: number;
}

export interface PaymentResponse {
  success: boolean;
  message: string;
  paymentId?: number;
  error?: string;
}

export const handlePayment: RequestHandler = async (req, res) => {
  try {
    const { registrationId, utr, transactionId, mobile, amount } = req.body as PaymentRequest;

    // Validation
    if (!registrationId || !utr || !transactionId || !mobile) {
      res.status(400).json({
        success: false,
        message: 'Missing required fields',
        error: 'registrationId, utr, transactionId, and mobile are required'
      } as PaymentResponse);
      return;
    }

    const connection = await pool.getConnection();

    // Verify registration exists
    const [registrationCheck] = await connection.execute(
      'SELECT id FROM registrations WHERE id = ?',
      [registrationId]
    );

    if ((registrationCheck as any[]).length === 0) {
      connection.release();
      res.status(404).json({
        success: false,
        message: 'Registration not found',
        error: 'Invalid registrationId'
      } as PaymentResponse);
      return;
    }

    // Insert payment record
    const [result] = await connection.execute(
      'INSERT INTO payments (registration_id, utr, transaction_id, mobile, amount, status) VALUES (?, ?, ?, ?, ?, ?)',
      [registrationId, utr, transactionId, mobile, amount || 0, 'pending']
    );

    connection.release();

    res.status(201).json({
      success: true,
      message: 'Payment submitted successfully',
      paymentId: (result as any).insertId
    } as PaymentResponse);
  } catch (error) {
    console.error('Payment error:', error);
    res.status(500).json({
      success: false,
      message: 'Payment submission failed',
      error: error instanceof Error ? error.message : 'Unknown error'
    } as PaymentResponse);
  }
};
