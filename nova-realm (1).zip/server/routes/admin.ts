import { RequestHandler } from 'express';
import pool from '../db';

export interface AdminRegistration {
  id: number;
  player_name: string;
  player_uid: string;
  player_mobile: string;
  mode: 'squad' | 'solo';
  created_at: string;
  payment?: AdminPayment;
}

export interface AdminPayment {
  id: number;
  utr: string;
  transaction_id: string;
  mobile: string;
  amount: number;
  status: string;
  created_at: string;
}

export interface AdminResponse {
  success: boolean;
  message: string;
  data?: any;
  error?: string;
}

// Get all registrations with their payments
export const handleGetRegistrations: RequestHandler = async (req, res) => {
  try {
    const connection = await pool.getConnection();

    const [registrations] = await connection.execute(`
      SELECT 
        r.id,
        r.player_name,
        r.player_uid,
        r.player_mobile,
        r.mode,
        r.created_at,
        p.id as payment_id,
        p.utr,
        p.transaction_id,
        p.mobile as payment_mobile,
        p.amount,
        p.status as payment_status,
        p.created_at as payment_created_at
      FROM registrations r
      LEFT JOIN payments p ON r.id = p.registration_id
      ORDER BY r.created_at DESC
    `);

    connection.release();

    res.json({
      success: true,
      message: 'Registrations retrieved successfully',
      data: registrations
    } as AdminResponse);
  } catch (error) {
    console.error('Get registrations error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve registrations',
      error: error instanceof Error ? error.message : 'Unknown error'
    } as AdminResponse);
  }
};

// Delete a registration and its associated payments
export const handleDeleteRegistration: RequestHandler = async (req, res) => {
  try {
    const { id } = req.params;

    if (!id || isNaN(parseInt(id))) {
      res.status(400).json({
        success: false,
        message: 'Invalid registration ID',
        error: 'Registration ID must be a valid number'
      } as AdminResponse);
      return;
    }

    const connection = await pool.getConnection();

    // Delete registration (payments will be deleted due to CASCADE)
    const [result] = await connection.execute(
      'DELETE FROM registrations WHERE id = ?',
      [parseInt(id)]
    );

    connection.release();

    if ((result as any).affectedRows === 0) {
      res.status(404).json({
        success: false,
        message: 'Registration not found',
        error: 'No registration found with the given ID'
      } as AdminResponse);
      return;
    }

    res.json({
      success: true,
      message: 'Registration deleted successfully'
    } as AdminResponse);
  } catch (error) {
    console.error('Delete registration error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete registration',
      error: error instanceof Error ? error.message : 'Unknown error'
    } as AdminResponse);
  }
};

// Delete all registrations (for post-match cleanup)
export const handleDeleteAllRegistrations: RequestHandler = async (req, res) => {
  try {
    const connection = await pool.getConnection();

    const [result] = await connection.execute('DELETE FROM registrations');

    connection.release();

    res.json({
      success: true,
      message: 'All registrations deleted successfully',
      data: { deletedCount: (result as any).affectedRows }
    } as AdminResponse);
  } catch (error) {
    console.error('Delete all registrations error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete registrations',
      error: error instanceof Error ? error.message : 'Unknown error'
    } as AdminResponse);
  }
};

// Get payment summary
export const handleGetPaymentSummary: RequestHandler = async (req, res) => {
  try {
    const connection = await pool.getConnection();

    const [summary] = await connection.execute(`
      SELECT 
        COUNT(DISTINCT r.id) as total_registrations,
        COUNT(DISTINCT p.id) as total_payments,
        SUM(CASE WHEN p.status = 'confirmed' THEN p.amount ELSE 0 END) as total_confirmed_amount,
        COUNT(DISTINCT CASE WHEN p.status = 'pending' THEN p.id END) as pending_payments,
        COUNT(DISTINCT CASE WHEN p.status = 'confirmed' THEN p.id END) as confirmed_payments
      FROM registrations r
      LEFT JOIN payments p ON r.id = p.registration_id
    `);

    connection.release();

    res.json({
      success: true,
      message: 'Payment summary retrieved successfully',
      data: (summary as any[])[0]
    } as AdminResponse);
  } catch (error) {
    console.error('Get payment summary error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve payment summary',
      error: error instanceof Error ? error.message : 'Unknown error'
    } as AdminResponse);
  }
};
