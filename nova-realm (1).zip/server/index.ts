import "dotenv/config";
import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import { initializeDatabase } from "./db";
import { handleRegister } from "./routes/registration";
import { handlePayment } from "./routes/payment";
import {
  handleGetRegistrations,
  handleDeleteRegistration,
  handleDeleteAllRegistrations,
  handleGetPaymentSummary,
} from "./routes/admin";

export async function createServer() {
  const app = express();

  // Initialize database
  try {
    await initializeDatabase();
  } catch (error) {
    console.error("Failed to initialize database:", error);
  }

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Example API routes
  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });

  app.get("/api/demo", handleDemo);

  // Tournament registration and payment routes
  app.post("/api/register", handleRegister);
  app.post("/api/payment", handlePayment);

  // Admin routes
  app.get("/api/admin/registrations", handleGetRegistrations);
  app.delete("/api/admin/registrations/:id", handleDeleteRegistration);
  app.delete("/api/admin/registrations", handleDeleteAllRegistrations);
  app.get("/api/admin/payment-summary", handleGetPaymentSummary);

  return app;
}
