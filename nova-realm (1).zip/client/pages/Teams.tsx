import { Layout } from "@/components/Layout";
import { Users, Zap } from "lucide-react";

export default function Teams() {
  return (
    <Layout>
      <div className="min-h-screen flex flex-col items-center justify-center">
        <div className="text-center">
          <Users className="w-20 h-20 mx-auto mb-6 text-cyan-400" />
          <h1 className="text-3xl md:text-4xl font-black text-white mb-4">
            Teams
          </h1>
          <p className="text-lg text-white/70 max-w-md mb-8">
            Browse all registered teams, view team rosters, statistics, and recent match results.
            Find and join a competitive team today!
          </p>
          <div className="flex items-center justify-center gap-2 text-purple-400 font-bold">
            <Zap className="w-5 h-5" />
            More content coming soon!
          </div>
        </div>
      </div>
    </Layout>
  );
}
