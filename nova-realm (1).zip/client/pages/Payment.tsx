import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Layout } from "@/components/Layout";
import { QrCode, Send, Loader, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

export default function Payment() {
  const navigate = useNavigate();
  const [step, setStep] = useState<"payment" | "verify">(
    "payment"
  );
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [playerName, setPlayerName] = useState("");
  const [registrationId, setRegistrationId] = useState<number | null>(null);

  const [formData, setFormData] = useState({
    utr: "",
    transactionId: "",
    mobile: "",
  });

  useEffect(() => {
    const storedRegId = sessionStorage.getItem("registrationId");
    const storedName = sessionStorage.getItem("playerName");

    if (!storedRegId) {
      toast.error("Please complete registration first");
      navigate("/register");
      return;
    }

    setRegistrationId(parseInt(storedRegId));
    setPlayerName(storedName || "Player");
  }, [navigate]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.utr.trim()) {
      toast.error("Please enter UTR");
      return;
    }

    if (!formData.transactionId.trim()) {
      toast.error("Please enter transaction ID");
      return;
    }

    if (!formData.mobile.trim() || formData.mobile.length < 10) {
      toast.error("Please enter a valid mobile number");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/payment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          registrationId,
          utr: formData.utr,
          transactionId: formData.transactionId,
          mobile: formData.mobile,
          amount: 99, // Default entry fee
        }),
      });

      const data = await response.json();

      if (data.success) {
        toast.success("Payment submitted successfully!");
        setSubmitted(true);
        sessionStorage.removeItem("registrationId");
        sessionStorage.removeItem("playerName");
        setTimeout(() => {
          navigate("/");
        }, 3000);
      } else {
        toast.error(data.message || "Payment submission failed");
      }
    } catch (error) {
      console.error("Payment error:", error);
      toast.error("Failed to submit payment. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <Layout>
        <div className="max-w-2xl mx-auto text-center py-12">
          <div className="bg-gradient-to-br from-green-600/20 to-green-600/10 border border-green-500/30 rounded-2xl p-12">
            <CheckCircle2 className="w-20 h-20 mx-auto mb-6 text-green-400 animate-bounce" />
            <h2 className="text-3xl md:text-4xl font-black text-white mb-4">
              Payment Received!
            </h2>
            <p className="text-lg text-white/70 mb-6">
              Your registration is complete. We'll verify your payment shortly
              and you'll receive a confirmation.
            </p>
            <p className="text-sm text-white/60">
              Redirecting to home page in a few seconds...
            </p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-3xl mx-auto">
        <div className="mb-12 text-center">
          <h1 className="text-4xl md:text-5xl font-black text-white mb-4">
            Complete Payment
          </h1>
          <p className="text-lg text-white/70">
            Entry fee: <span className="text-cyan-400 font-bold">₹99</span>
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* QR Code Section */}
          <div className="bg-gradient-to-br from-[#2a1f1a] to-[#1a2a2a] border border-cyan-500/20 rounded-2xl p-8 flex flex-col items-center justify-center">
            <div className="mb-6">
              <QrCode className="w-12 h-12 text-cyan-400" />
            </div>
            <h3 className="text-2xl font-black text-white mb-6 text-center">
              Scan QR Code
            </h3>

            {/* QR Code Placeholder */}
            <div className="w-64 h-64 bg-gradient-to-br from-white/10 to-white/5 border-2 border-dashed border-cyan-500/40 rounded-lg flex items-center justify-center mb-6">
              <div className="text-center">
                <QrCode className="w-20 h-20 text-cyan-400 opacity-50 mx-auto mb-3" />
                <p className="text-white/50 text-sm">
                  QR Code will be displayed here
                </p>
              </div>
            </div>

            {/* UPI ID */}
            <div className="w-full">
              <p className="text-center text-white/70 mb-2">Or pay to UPI ID:</p>
              <div className="bg-[#1a1410] border border-cyan-500/30 rounded-lg p-4 text-center">
                <p className="text-cyan-400 font-bold text-lg break-all">
                  tournament@upi
                </p>
              </div>
            </div>
          </div>

          {/* Form Section */}
          <div className="bg-gradient-to-br from-[#2a1f1a] to-[#1a2a2a] border border-cyan-500/20 rounded-2xl p-8">
            <h3 className="text-2xl font-black text-white mb-2">
              Enter Transaction Details
            </h3>
            <p className="text-white/60 text-sm mb-6">
              After making the payment via UPI
            </p>

            <form onSubmit={handlePaymentSubmit} className="space-y-6">
              {/* Player Name (Display) */}
              <div>
                <label className="block text-sm font-bold text-white/80 mb-2">
                  Player Name
                </label>
                <div className="px-4 py-3 bg-[#1a1410]/50 border border-cyan-500/30 rounded-lg">
                  <p className="text-white font-semibold">{playerName}</p>
                </div>
              </div>

              {/* UTR */}
              <div>
                <label className="block text-sm font-bold text-white/80 mb-2">
                  UTR (Unique Transaction Reference)
                </label>
                <input
                  type="text"
                  name="utr"
                  value={formData.utr}
                  onChange={handleInputChange}
                  placeholder="Enter 12-digit UTR"
                  maxLength={12}
                  className="w-full px-4 py-3 bg-[#1a1410] border border-cyan-500/30 focus:border-cyan-500 focus:outline-none text-white placeholder-white/40 rounded-lg transition-all duration-300"
                  disabled={loading}
                />
                <p className="text-xs text-white/50 mt-1">
                  Find in your payment confirmation or bank statement
                </p>
              </div>

              {/* Transaction ID */}
              <div>
                <label className="block text-sm font-bold text-white/80 mb-2">
                  Transaction ID
                </label>
                <input
                  type="text"
                  name="transactionId"
                  value={formData.transactionId}
                  onChange={handleInputChange}
                  placeholder="Enter transaction ID"
                  className="w-full px-4 py-3 bg-[#1a1410] border border-cyan-500/30 focus:border-cyan-500 focus:outline-none text-white placeholder-white/40 rounded-lg transition-all duration-300"
                  disabled={loading}
                />
                <p className="text-xs text-white/50 mt-1">
                  Transaction reference from UPI app
                </p>
              </div>

              {/* Mobile Number */}
              <div>
                <label className="block text-sm font-bold text-white/80 mb-2">
                  Mobile Number (Used for Payment)
                </label>
                <input
                  type="tel"
                  name="mobile"
                  value={formData.mobile}
                  onChange={handleInputChange}
                  placeholder="Enter your mobile number"
                  className="w-full px-4 py-3 bg-[#1a1410] border border-cyan-500/30 focus:border-cyan-500 focus:outline-none text-white placeholder-white/40 rounded-lg transition-all duration-300"
                  disabled={loading}
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={loading}
                className="w-full py-4 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-500 hover:to-green-600 disabled:from-green-600/50 disabled:to-green-700/50 text-white font-bold rounded-lg transition-all duration-300 transform hover:scale-105 disabled:hover:scale-100 flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <Loader className="w-5 h-5 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    Submit Payment Details
                  </>
                )}
              </button>

              <p className="text-xs text-white/50 text-center">
                ✓ Your payment will be verified within 24 hours
              </p>
            </form>
          </div>
        </div>
      </div>
    </Layout>
  );
}
