import { Layout } from "@/components/Layout";
import {
  Users,
  Trophy,
  BarChart3,
  Trash2,
  RefreshCw,
  AlertTriangle,
  Loader,
} from "lucide-react";
import { useState, useEffect } from "react";
import { toast } from "sonner";

interface Registration {
  id: number;
  player_name: string;
  player_uid: string;
  player_mobile: string;
  mode: "squad" | "solo";
  created_at: string;
  payment_id?: number;
  utr?: string;
  transaction_id?: string;
  payment_mobile?: string;
  amount?: number;
  payment_status?: string;
  payment_created_at?: string;
}

interface PaymentSummary {
  total_registrations: number;
  total_payments: number;
  total_confirmed_amount: number;
  pending_payments: number;
  confirmed_payments: number;
}

export default function Admin() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [loading, setLoading] = useState(false);
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [summary, setSummary] = useState<PaymentSummary | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);

  const loadData = async () => {
    setLoading(true);
    try {
      const [regRes, sumRes] = await Promise.all([
        fetch("/api/admin/registrations"),
        fetch("/api/admin/payment-summary"),
      ]);

      const regData = await regRes.json();
      const sumData = await sumRes.json();

      if (regData.success) {
        setRegistrations(regData.data || []);
      }
      if (sumData.success) {
        setSummary(sumData.data);
      }
    } catch (error) {
      console.error("Failed to load data:", error);
      toast.error("Failed to load admin data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleDeleteRegistration = async (id: number) => {
    try {
      const response = await fetch(`/api/admin/registrations/${id}`, {
        method: "DELETE",
      });

      const data = await response.json();

      if (data.success) {
        toast.success("Registration deleted");
        setDeleteConfirm(null);
        loadData();
      } else {
        toast.error(data.message || "Failed to delete");
      }
    } catch (error) {
      console.error("Delete error:", error);
      toast.error("Failed to delete registration");
    }
  };

  const handleDeleteAllRegistrations = async () => {
    if (!confirm("Are you sure? This will delete all registrations!")) {
      return;
    }

    try {
      const response = await fetch("/api/admin/registrations", {
        method: "DELETE",
      });

      const data = await response.json();

      if (data.success) {
        toast.success(
          `Deleted ${data.data.deletedCount} registrations successfully`
        );
        loadData();
      } else {
        toast.error(data.message || "Failed to delete all");
      }
    } catch (error) {
      console.error("Delete all error:", error);
      toast.error("Failed to delete all registrations");
    }
  };

  const adminStats = [
    {
      label: "Total Registrations",
      value: summary?.total_registrations || 0,
      icon: Users,
      color: "text-cyan-400",
    },
    {
      label: "Total Payments",
      value: summary?.total_payments || 0,
      icon: BarChart3,
      color: "text-purple-400",
    },
    {
      label: "Confirmed Payments",
      value: summary?.confirmed_payments || 0,
      icon: Trophy,
      color: "text-yellow-400",
    },
    {
      label: "Pending Payments",
      value: summary?.pending_payments || 0,
      icon: AlertTriangle,
      color: "text-orange-400",
    },
  ];

  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-4xl md:text-5xl font-black text-white mb-4">
          Admin Dashboard
        </h1>
        <p className="text-lg text-white/70">
          Manage registrations and tournament entries
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
        {adminStats.map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <div
              key={idx}
              className="bg-gradient-to-br from-[#2a1f1a] to-[#1a2a2a] border border-cyan-500/20 rounded-xl p-6 hover:border-cyan-500/40 transition-all duration-300"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-sm font-bold text-white/70 mb-2">
                    {stat.label}
                  </div>
                  <div className="text-3xl md:text-4xl font-black text-white">
                    {stat.value}
                  </div>
                </div>
                <Icon className={`w-8 h-8 ${stat.color} opacity-70`} />
              </div>
            </div>
          );
        })}
      </div>

      {/* Tabs */}
      <div className="mb-8 border-b border-cyan-500/20">
        <div className="flex gap-8">
          {["dashboard", "registrations"].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`py-4 px-2 font-bold text-lg capitalize transition-all duration-300 border-b-2 ${
                activeTab === tab
                  ? "text-cyan-400 border-cyan-400"
                  : "text-white/60 hover:text-white/80 border-transparent"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      {activeTab === "dashboard" && (
        <div className="space-y-8">
          <div className="bg-gradient-to-r from-[#2a1f1a] to-[#1f2a2a] border border-cyan-500/20 rounded-xl p-6">
            <h3 className="text-xl font-black text-white mb-6">
              Recent Activity
            </h3>

            <div className="space-y-4">
              <div className="flex items-center justify-between pb-4 border-b border-cyan-500/10">
                <p className="text-white/70">Total Registrations</p>
                <p className="text-2xl font-black text-cyan-400">
                  {summary?.total_registrations || 0}
                </p>
              </div>

              <div className="flex items-center justify-between pb-4 border-b border-cyan-500/10">
                <p className="text-white/70">Payments Received</p>
                <p className="text-2xl font-black text-green-400">
                  {summary?.confirmed_payments || 0}
                </p>
              </div>

              <div className="flex items-center justify-between pb-4 border-b border-cyan-500/10">
                <p className="text-white/70">Pending Payments</p>
                <p className="text-2xl font-black text-orange-400">
                  {summary?.pending_payments || 0}
                </p>
              </div>

              <div className="flex items-center justify-between">
                <p className="text-white/70">Total Confirmed Amount</p>
                <p className="text-2xl font-black text-yellow-400">
                  ₹{summary?.total_confirmed_amount || 0}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === "registrations" && (
        <div>
          <div className="flex items-center justify-between mb-6 flex-col sm:flex-row gap-4">
            <h2 className="text-2xl font-black text-white flex items-center gap-3">
              <Users className="w-6 h-6 text-cyan-400" />
              All Registrations
            </h2>

            <div className="flex gap-3">
              <button
                onClick={loadData}
                disabled={loading}
                className="px-4 py-3 bg-cyan-500/20 border border-cyan-500 text-cyan-400 rounded-lg hover:bg-cyan-500/30 transition-all duration-300 flex items-center gap-2"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
                Refresh
              </button>

              <button
                onClick={handleDeleteAllRegistrations}
                className="px-4 py-3 bg-red-500/20 border border-red-500 text-red-400 rounded-lg hover:bg-red-500/30 transition-all duration-300 flex items-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                Clear All
              </button>
            </div>
          </div>

          {loading ? (
            <div className="flex justify-center py-12">
              <Loader className="w-8 h-8 text-cyan-400 animate-spin" />
            </div>
          ) : registrations.length === 0 ? (
            <div className="bg-gradient-to-r from-[#2a1f1a] to-[#1f2a2a] border border-cyan-500/20 rounded-xl p-12 text-center">
              <Users className="w-12 h-12 mx-auto mb-4 text-cyan-400 opacity-50" />
              <p className="text-white/70 text-lg">No registrations yet</p>
            </div>
          ) : (
            <div className="space-y-4">
              {registrations.map((reg) => (
                <div
                  key={reg.id}
                  className="bg-gradient-to-r from-[#2a1f1a] to-[#1f2a2a] border border-cyan-500/20 rounded-xl p-6 hover:border-cyan-500/40 transition-all duration-300"
                >
                  <div className="flex items-start justify-between flex-col md:flex-row gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg font-black text-white">
                          {reg.player_name}
                        </h3>
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${
                            reg.mode === "solo"
                              ? "bg-cyan-500/30 text-cyan-400 border border-cyan-500/50"
                              : "bg-purple-500/30 text-purple-400 border border-purple-500/50"
                          }`}
                        >
                          {reg.mode}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
                        <div>
                          <p className="text-white/50">Free Fire UID</p>
                          <p className="text-white font-semibold">
                            {reg.player_uid}
                          </p>
                        </div>
                        <div>
                          <p className="text-white/50">Mobile</p>
                          <p className="text-white font-semibold">
                            {reg.player_mobile}
                          </p>
                        </div>
                        <div>
                          <p className="text-white/50">Registered</p>
                          <p className="text-white font-semibold">
                            {new Date(reg.created_at).toLocaleDateString()}
                          </p>
                        </div>
                      </div>

                      {reg.payment_id && (
                        <div className="mt-4 pt-4 border-t border-cyan-500/10">
                          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-sm">
                            <div>
                              <p className="text-white/50">UTR</p>
                              <p className="text-green-400 font-semibold">
                                {reg.utr}
                              </p>
                            </div>
                            <div>
                              <p className="text-white/50">Transaction ID</p>
                              <p className="text-white font-semibold break-all">
                                {reg.transaction_id}
                              </p>
                            </div>
                            <div>
                              <p className="text-white/50">Amount</p>
                              <p className="text-yellow-400 font-semibold">
                                ₹{reg.amount || 0}
                              </p>
                            </div>
                            <div>
                              <p className="text-white/50">Status</p>
                              <p
                                className={`font-semibold ${
                                  reg.payment_status === "confirmed"
                                    ? "text-green-400"
                                    : "text-orange-400"
                                }`}
                              >
                                {reg.payment_status || "N/A"}
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="flex gap-2">
                      {deleteConfirm === reg.id ? (
                        <>
                          <button
                            onClick={() =>
                              handleDeleteRegistration(reg.id)
                            }
                            className="px-3 py-2 bg-red-500/30 border border-red-500 text-red-400 rounded hover:bg-red-500/40 transition-all duration-300 text-sm font-bold"
                          >
                            Confirm Delete
                          </button>
                          <button
                            onClick={() => setDeleteConfirm(null)}
                            className="px-3 py-2 bg-white/10 border border-white/20 text-white rounded hover:bg-white/20 transition-all duration-300 text-sm font-bold"
                          >
                            Cancel
                          </button>
                        </>
                      ) : (
                        <button
                          onClick={() => setDeleteConfirm(reg.id)}
                          className="p-2 bg-red-500/20 border border-red-500 text-red-400 rounded hover:bg-red-500/30 transition-all duration-300"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </Layout>
  );
}
