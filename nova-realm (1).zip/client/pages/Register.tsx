import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Layout } from "@/components/Layout";
import { Users, User, ArrowRight, Loader } from "lucide-react";
import { toast } from "sonner";

export default function Register() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"squad" | "solo" | null>(null);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    playerName: "",
    playerUid: "",
    playerMobile: "",
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!mode) {
      toast.error("Please select Squad or Solo mode");
      return;
    }

    if (!formData.playerName.trim()) {
      toast.error("Please enter your name");
      return;
    }

    if (!formData.playerUid.trim()) {
      toast.error("Please enter your Free Fire UID");
      return;
    }

    if (!formData.playerMobile.trim() || formData.playerMobile.length < 10) {
      toast.error("Please enter a valid mobile number");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          playerName: formData.playerName,
          playerUid: formData.playerUid,
          playerMobile: formData.playerMobile,
          mode: mode,
        }),
      });

      const data = await response.json();

      if (data.success) {
        toast.success("Registration successful!");
        sessionStorage.setItem("registrationId", data.registrationId);
        sessionStorage.setItem("playerName", formData.playerName);
        navigate("/payment");
      } else {
        toast.error(data.message || "Registration failed");
      }
    } catch (error) {
      console.error("Registration error:", error);
      toast.error("Failed to register. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <div className="max-w-2xl mx-auto">
        <div className="mb-12 text-center">
          <h1 className="text-4xl md:text-5xl font-black text-white mb-4">
            Join the Tournament
          </h1>
          <p className="text-lg text-white/70">
            Choose your mode and register for the upcoming match
          </p>
        </div>

        {/* Mode Selection */}
        {!mode ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
            <button
              onClick={() => setMode("solo")}
              className="group relative overflow-hidden rounded-xl bg-gradient-to-br from-cyan-600/20 to-cyan-600/10 border-2 border-cyan-500/30 hover:border-cyan-500/70 p-8 transition-all duration-300 transform hover:scale-105"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <div className="relative z-10 text-center">
                <User className="w-16 h-16 mx-auto mb-4 text-cyan-400 group-hover:scale-110 transition-transform" />
                <h2 className="text-2xl font-black text-white mb-2">SOLO MODE</h2>
                <p className="text-white/70 mb-6">Play individually and compete with your own skills</p>
                <div className="flex items-center justify-center gap-2 text-cyan-400 font-bold">
                  Select <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </button>

            <button
              onClick={() => setMode("squad")}
              className="group relative overflow-hidden rounded-xl bg-gradient-to-br from-purple-600/20 to-purple-600/10 border-2 border-purple-500/30 hover:border-purple-500/70 p-8 transition-all duration-300 transform hover:scale-105"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <div className="relative z-10 text-center">
                <Users className="w-16 h-16 mx-auto mb-4 text-purple-400 group-hover:scale-110 transition-transform" />
                <h2 className="text-2xl font-black text-white mb-2">SQUAD MODE</h2>
                <p className="text-white/70 mb-6">Team up with friends and dominate the competition</p>
                <div className="flex items-center justify-center gap-2 text-purple-400 font-bold">
                  Select <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </button>
          </div>
        ) : (
          <>
            {/* Mode Selected - Show Form */}
            <div className="mb-6">
              <button
                onClick={() => setMode(null)}
                className="text-cyan-400 hover:text-cyan-300 font-bold flex items-center gap-2 transition-colors"
              >
                ← Change Mode
              </button>
            </div>

            <div className="bg-gradient-to-br from-[#2a1f1a] to-[#1a2a2a] border border-cyan-500/20 rounded-2xl p-8 md:p-12">
              <div className="mb-8 text-center">
                <div className="inline-block px-4 py-2 bg-gradient-to-r from-purple-600/30 to-cyan-600/30 border border-cyan-500/50 rounded-full mb-4">
                  <span className="font-bold text-cyan-400 uppercase text-sm">
                    {mode === "solo" ? "🎮 Solo" : "👥 Squad"}
                  </span>
                </div>
                <h2 className="text-3xl font-black text-white mb-2">Registration Form</h2>
                <p className="text-white/70">Fill in your details to register</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Player Name */}
                <div>
                  <label className="block text-sm font-bold text-white/80 mb-2">
                    Player Name
                  </label>
                  <input
                    type="text"
                    name="playerName"
                    value={formData.playerName}
                    onChange={handleInputChange}
                    placeholder="Enter your in-game name"
                    className="w-full px-4 py-3 bg-[#1a1410] border border-cyan-500/30 focus:border-cyan-500 focus:outline-none text-white placeholder-white/40 rounded-lg transition-all duration-300"
                    disabled={loading}
                  />
                </div>

                {/* Free Fire UID */}
                <div>
                  <label className="block text-sm font-bold text-white/80 mb-2">
                    Free Fire UID
                  </label>
                  <input
                    type="text"
                    name="playerUid"
                    value={formData.playerUid}
                    onChange={handleInputChange}
                    placeholder="Enter your Free Fire UID (e.g., 123456789)"
                    className="w-full px-4 py-3 bg-[#1a1410] border border-cyan-500/30 focus:border-cyan-500 focus:outline-none text-white placeholder-white/40 rounded-lg transition-all duration-300"
                    disabled={loading}
                  />
                  <p className="text-xs text-white/50 mt-1">
                    Find your UID in the Free Fire profile settings
                  </p>
                </div>

                {/* Mobile Number */}
                <div>
                  <label className="block text-sm font-bold text-white/80 mb-2">
                    Mobile Number
                  </label>
                  <input
                    type="tel"
                    name="playerMobile"
                    value={formData.playerMobile}
                    onChange={handleInputChange}
                    placeholder="Enter your 10-digit mobile number"
                    className="w-full px-4 py-3 bg-[#1a1410] border border-cyan-500/30 focus:border-cyan-500 focus:outline-none text-white placeholder-white/40 rounded-lg transition-all duration-300"
                    disabled={loading}
                  />
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-4 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-500 hover:to-purple-600 disabled:from-purple-600/50 disabled:to-purple-700/50 text-white font-bold rounded-lg transition-all duration-300 transform hover:scale-105 disabled:hover:scale-100 flex items-center justify-center gap-2"
                >
                  {loading ? (
                    <>
                      <Loader className="w-5 h-5 animate-spin" />
                      Registering...
                    </>
                  ) : (
                    <>
                      Continue to Payment
                      <ArrowRight className="w-5 h-5" />
                    </>
                  )}
                </button>
              </form>
            </div>
          </>
        )}
      </div>
    </Layout>
  );
}
