import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Layout } from "@/components/Layout";
import { Link } from "react-router-dom";
import { AlertTriangle } from "lucide-react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname,
    );
  }, [location.pathname]);

  return (
    <Layout>
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle className="w-24 h-24 mx-auto mb-6 text-red-400 animate-bounce" />
          <h1 className="text-6xl md:text-7xl font-black text-transparent bg-gradient-to-r from-red-400 to-pink-400 bg-clip-text mb-4">
            404
          </h1>
          <p className="text-2xl md:text-3xl font-bold text-white mb-4">
            Match Not Found!
          </p>
          <p className="text-lg text-white/70 mb-8 max-w-md mx-auto">
            The page you're looking for doesn't exist. Maybe it got eliminated from the tournament?
          </p>
          <Link
            to="/"
            className="inline-block px-8 py-4 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-500 hover:to-purple-600 text-white font-bold rounded-lg transition-all duration-300 transform hover:scale-105"
          >
            Return to Battle
          </Link>
        </div>
      </div>
    </Layout>
  );
};

export default NotFound;
