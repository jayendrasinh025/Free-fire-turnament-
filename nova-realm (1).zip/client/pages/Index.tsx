import { Link } from "react-router-dom";
import { Layout } from "@/components/Layout";
import { Flame, Trophy, Users, Clock, MapPin, DollarSign } from "lucide-react";

export default function Index() {
  const featuredTournaments = [
    {
      id: 1,
      name: "FIRE CLASH ELITE SERIES",
      status: "LIVE NOW",
      prizePool: "$50,000",
      teams: 64,
      startDate: "Dec 22, 2024",
      location: "Global",
      image: "bg-gradient-to-br from-purple-600/30 to-pink-600/30",
    },
    {
      id: 2,
      name: "WINTER CHAMPIONSHIP",
      status: "STARTING IN 2 DAYS",
      prizePool: "$75,000",
      teams: 128,
      startDate: "Dec 24, 2024",
      location: "Global",
      image: "bg-gradient-to-br from-cyan-600/30 to-blue-600/30",
    },
    {
      id: 3,
      name: "ROOKIE TOURNAMENT",
      status: "OPEN FOR SIGNUP",
      prizePool: "$10,000",
      teams: 32,
      startDate: "Dec 26, 2024",
      location: "Global",
      image: "bg-gradient-to-br from-yellow-600/30 to-orange-600/30",
    },
  ];

  const upcomingMatches = [
    {
      id: 1,
      team1: "Phoenix Rising",
      team2: "Dragon Hunters",
      time: "Today, 6:00 PM",
      round: "Round 1",
    },
    {
      id: 2,
      team1: "Cyber Warriors",
      team2: "Inferno Squad",
      time: "Today, 8:00 PM",
      round: "Round 1",
    },
    {
      id: 3,
      team1: "Elite Force",
      team2: "Storm Breakers",
      time: "Tomorrow, 5:00 PM",
      round: "Round 2",
    },
  ];

  const topTeams = [
    { rank: 1, name: "Phoenix Rising", points: 2450, members: 5 },
    { rank: 2, name: "Dragon Hunters", points: 2380, members: 5 },
    { rank: 3, name: "Cyber Warriors", points: 2290, members: 5 },
    { rank: 4, name: "Inferno Squad", points: 2180, members: 5 },
    { rank: 5, name: "Elite Force", points: 2050, members: 5 },
  ];

  return (
    <Layout>
      {/* Hero Section */}
      <section className="mb-20">
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-purple-600/20 via-cyan-600/20 to-pink-600/20 border border-cyan-500/30 p-8 md:p-16">
          {/* Animated background elements */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-purple-600/10 rounded-full mix-blend-multiply filter blur-3xl animate-pulse"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-cyan-600/10 rounded-full mix-blend-multiply filter blur-3xl animate-pulse delay-7000"></div>

          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-4">
              <Flame className="w-8 h-8 text-orange-400" />
              <span className="text-orange-400 font-bold text-sm md:text-base">
                ELITE TOURNAMENT SERIES
              </span>
            </div>

            <h1 className="text-4xl md:text-6xl font-black mb-4 text-white leading-tight">
              Welcome to{" "}
              <span className="bg-gradient-to-r from-purple-400 via-cyan-400 to-pink-400 bg-clip-text text-transparent">
                FIRE CLASH
              </span>
            </h1>

            <p className="text-lg md:text-xl text-white/80 max-w-2xl mb-8">
              The most competitive Free Fire tournament platform with real prizes,
              global competition, and world-class gameplay.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                to="/register"
                className="px-8 py-4 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-500 hover:to-purple-600 text-white font-bold rounded-lg transition-all duration-300 transform hover:scale-105 text-center"
              >
                Join Tournament
              </Link>
              <button className="px-8 py-4 bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500 text-cyan-300 font-bold rounded-lg transition-all duration-300">
                Watch Live
              </button>
            </div>

            <div className="grid grid-cols-3 gap-4 mt-12">
              <div className="text-center">
                <div className="text-2xl md:text-3xl font-black text-cyan-400">
                  $500K+
                </div>
                <div className="text-sm md:text-base text-white/70">Prize Pool</div>
              </div>
              <div className="text-center">
                <div className="text-2xl md:text-3xl font-black text-purple-400">
                  2000+
                </div>
                <div className="text-sm md:text-base text-white/70">Players</div>
              </div>
              <div className="text-center">
                <div className="text-2xl md:text-3xl font-black text-pink-400">
                  50+
                </div>
                <div className="text-sm md:text-base text-white/70">Teams</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Tournaments */}
      <section className="mb-20">
        <h2 className="text-3xl md:text-4xl font-black text-white mb-8">
          Featured Tournaments
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredTournaments.map((tournament) => (
            <Link
              key={tournament.id}
              to="/tournaments"
              className="group cursor-pointer"
            >
              <div
                className={`${tournament.image} border border-cyan-500/30 rounded-xl p-6 hover:border-cyan-500/60 transition-all duration-300 h-full flex flex-col justify-between`}
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="px-3 py-1 bg-red-500/30 border border-red-500 text-red-300 text-xs font-bold rounded-full">
                      {tournament.status}
                    </span>
                    <Trophy className="w-5 h-5 text-yellow-400" />
                  </div>

                  <h3 className="text-xl md:text-2xl font-black text-white mb-4 group-hover:text-cyan-400 transition-colors">
                    {tournament.name}
                  </h3>

                  <div className="space-y-2 text-sm text-white/70">
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-green-400" />
                      <span>Prize Pool: {tournament.prizePool}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-cyan-400" />
                      <span>{tournament.teams} Teams</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-purple-400" />
                      <span>{tournament.startDate}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-pink-400" />
                      <span>{tournament.location}</span>
                    </div>
                  </div>
                </div>

                <button className="mt-6 w-full py-2 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-500 hover:to-purple-600 text-white font-bold rounded-lg transition-all duration-300">
                  View Details
                </button>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Upcoming Matches */}
      <section className="mb-20">
        <h2 className="text-3xl md:text-4xl font-black text-white mb-8">
          Upcoming Matches
        </h2>

        <div className="space-y-4">
          {upcomingMatches.map((match) => (
            <div
              key={match.id}
              className="bg-gradient-to-r from-[#2a1f1a] to-[#1f2a2a] border border-cyan-500/20 rounded-xl p-6 hover:border-cyan-500/50 transition-all duration-300"
            >
              <div className="flex items-center justify-between flex-col md:flex-row gap-6">
                <div className="flex-1 text-center md:text-left">
                  <div className="text-xs font-bold text-purple-400 mb-2">
                    {match.round}
                  </div>
                  <div className="flex flex-col md:flex-row items-center gap-4">
                    <div className="font-bold text-white text-lg">
                      {match.team1}
                    </div>
                    <div className="text-cyan-400 font-black text-xl hidden md:block">
                      VS
                    </div>
                    <div className="font-bold text-white text-lg">
                      {match.team2}
                    </div>
                  </div>
                </div>

                <div className="text-right md:text-left">
                  <div className="text-sm text-white/70">{match.time}</div>
                  <button className="mt-2 px-4 py-2 bg-cyan-500/20 border border-cyan-500 text-cyan-300 font-bold rounded-lg hover:bg-cyan-500/30 transition-all duration-300">
                    Watch
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Top Teams */}
      <section>
        <h2 className="text-3xl md:text-4xl font-black text-white mb-8">
          Top Teams
        </h2>

        <div className="bg-gradient-to-b from-[#2a1f1a]/50 to-transparent border border-cyan-500/20 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gradient-to-r from-purple-600/30 to-cyan-600/30 border-b border-cyan-500/30">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-black text-white">
                    RANK
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-black text-white">
                    TEAM
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-black text-white">
                    POINTS
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-black text-white">
                    MEMBERS
                  </th>
                </tr>
              </thead>
              <tbody>
                {topTeams.map((team, idx) => (
                  <tr
                    key={team.rank}
                    className={`border-b border-cyan-500/10 hover:bg-cyan-500/5 transition-colors ${
                      idx < 3 ? "bg-gradient-to-r from-yellow-600/10 to-transparent" : ""
                    }`}
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-600 to-cyan-600 flex items-center justify-center font-black text-white">
                          {team.rank}
                        </div>
                        {team.rank === 1 && <Trophy className="w-5 h-5 text-yellow-400" />}
                      </div>
                    </td>
                    <td className="px-6 py-4 font-bold text-white">
                      {team.name}
                    </td>
                    <td className="px-6 py-4 font-bold text-cyan-400">
                      {team.points}
                    </td>
                    <td className="px-6 py-4 text-white/70">
                      {team.members} players
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </Layout>
  );
}
