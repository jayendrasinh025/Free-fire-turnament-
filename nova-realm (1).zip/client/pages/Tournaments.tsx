import { Layout } from "@/components/Layout";
import { Trophy, Zap } from "lucide-react";

export default function Tournaments() {
  return (
    <Layout>
      <div className="min-h-screen flex flex-col items-center justify-center">
        <div className="text-center">
          <Trophy className="w-20 h-20 mx-auto mb-6 text-cyan-400" />
          <h1 className="text-3xl md:text-4xl font-black text-white mb-4">
            Tournaments
          </h1>
          <p className="text-lg text-white/70 max-w-md mb-8">
            This page will showcase all available tournaments with detailed information,
            registration, and current standings.
          </p>
          <div className="flex items-center justify-center gap-2 text-purple-400 font-bold">
            <Zap className="w-5 h-5" />
            More content coming soon!
          </div>
        </div>
      </div>
    </Layout>
  );
}
