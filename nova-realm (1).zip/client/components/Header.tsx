import { Link } from "react-router-dom";
import { Menu, X } from "lucide-react";
import { useState } from "react";

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-gradient-to-r from-[#1a1410] via-[#1a1410] to-[#2a1815] border-b border-[#00ffff]/20 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16 md:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group">
            <div className="relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 to-cyan-500 rounded-lg blur opacity-75 group-hover:opacity-100 transition duration-300"></div>
              <div className="relative bg-[#1a1410] px-3 py-2 rounded-lg">
                <span className="font-black text-lg md:text-xl bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
                  FF
                </span>
              </div>
            </div>
            <div className="hidden sm:block">
              <div className="text-sm md:text-base font-bold text-white">FIRE CLASH</div>
              <div className="text-xs text-cyan-400">TOURNAMENT</div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <Link
              to="/"
              className="text-sm font-medium text-white/80 hover:text-cyan-400 transition-colors"
            >
              Home
            </Link>
            <Link
              to="/tournaments"
              className="text-sm font-medium text-white/80 hover:text-cyan-400 transition-colors"
            >
              Tournaments
            </Link>
            <Link
              to="/leaderboard"
              className="text-sm font-medium text-white/80 hover:text-cyan-400 transition-colors"
            >
              Leaderboard
            </Link>
            <Link
              to="/teams"
              className="text-sm font-medium text-white/80 hover:text-cyan-400 transition-colors"
            >
              Teams
            </Link>
            <Link
              to="/admin"
              className="px-4 py-2 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-500 hover:to-purple-600 text-white text-sm font-semibold rounded-lg transition-all duration-300"
            >
              Admin Panel
            </Link>
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-white hover:text-cyan-400 transition-colors"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden pb-4 border-t border-[#00ffff]/20 pt-4 space-y-3">
            <Link
              to="/"
              className="block px-4 py-2 text-sm font-medium text-white/80 hover:text-cyan-400 transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              to="/tournaments"
              className="block px-4 py-2 text-sm font-medium text-white/80 hover:text-cyan-400 transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Tournaments
            </Link>
            <Link
              to="/leaderboard"
              className="block px-4 py-2 text-sm font-medium text-white/80 hover:text-cyan-400 transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Leaderboard
            </Link>
            <Link
              to="/teams"
              className="block px-4 py-2 text-sm font-medium text-white/80 hover:text-cyan-400 transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Teams
            </Link>
            <Link
              to="/admin"
              className="block mx-4 px-4 py-2 bg-gradient-to-r from-purple-600 to-purple-700 text-white text-sm font-semibold rounded-lg hover:from-purple-500 hover:to-purple-600 transition-all duration-300"
              onClick={() => setMobileMenuOpen(false)}
            >
              Admin Panel
            </Link>
          </nav>
        )}
      </div>
    </header>
  );
}
